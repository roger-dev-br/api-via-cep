import cepService from '../services/cepService';

class CepController {
    // http://localhost:3333/cep/01200030
    show = (req, res) => {
        const { cep } = req.params;

        // URL do viacep
        const url = `${cep}/json/`;

        cepService.get(url).then(response => {
            res.json(response.data);            
        });
    }
}

export default new CepController();