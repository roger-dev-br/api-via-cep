import { Router } from 'express';

import logRequestsMiddleware from './app/middlewares/logRequests';

import cepController from './app/controllers/cepController';

const routes = new Router();

routes.use(logRequestsMiddleware);

// Busca CEP exato
routes.get('/cep/:cep', cepController.show);

export default routes;
